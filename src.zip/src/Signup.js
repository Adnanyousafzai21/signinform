import React from "react";
import { makeStyles } from "@mui/material/styles";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import { Link } from "react-router-dom";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import { useState } from "react";
import NativeSelect from "@mui/material/NativeSelect";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import { Grid } from "@mui/material";

const Signup = () => {
  const [data, setdata] = useState({
    fname: "",
    lname: "",
    email: "",
    birthday: "",
    phone: "",
    password: "",
    address: "",
    confrim_password: "",
  });
  const update = (e) => {
    const value = e.target.value;
    const name = e.target.name;
    setdata((pre) => {
      return {
        ...pre,
        [name]: value,
      };
    });
  };
  const handleChange = () => {};
  const Submit = () => {
    alert(
      `fname ::: ${data.fname} Lname :::${data.lname} Email::: ${data.email} Birthday :::${data.birthday} Phone :::${data.phone} Password::: ${data.password} Confrim_password :::${data.confrim_password} Address ${data.address}`
    );
  };
  return (
    <>
      <div className="contianer">
        <form className="form">
          {/* <p>{data.fname}{data.lname}{data.email}{data.phone}{data.password}{data.confrim_password}{data.birthday}</p> */}
          <h1>Sign Up</h1>
          <div className="inputFeild">
            <TextField
              id="outlined-basic"
              label="F/Name"
              onChange={update}
              style={{ width: "47%" }}
              name="fname"
              value={data.fname}
            />
            <TextField
              className="LName"
              id="outlined-basic"
              sx={{
                width: { sm: 200, md: 300 },
                "& .MuiInputBase-root": {
                  height: "55px",
                },
              }}
              label="L/Name"
              style={{ width: "47%" }}
              onChange={update}
              name="lname"
              value={data.lname}
            />
          </div>
          <div className="inputFeild">
            <TextField
              id="outlined-basic"
              label="Email"
              type="email"
              style={{ width: "97%" }}
              onChange={update}
              name="email"
              value={data.email}
              required
            />
          </div>

          <div className="inputFeild">
            <TextField
              id="outlined-basic"
              label=""
              type="date"
              style={{ width: "47%" }}
              onChange={update}
              name="birthday"
              value={data.birthday}
            />
            <TextField
              id="outlined-basic"
              label="Mobile"
              type="number"
              style={{ width: "47%" }}
              onChange={update}
              name="phone"
              value={data.phone}
            />
          </div>
          <div className="inputFeild">
            <FormControl
              variant="outlined"
              // className={classes.formControl}
              style={{ width: "47%" }}
            >
              <InputLabel id="demo-simple-select-outlined-label">
                Select-city
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                // value={age}
                // onChange={handleChange}
                label="select-contry"
              >
                <MenuItem value="">
                  <em>None</em>
                </MenuItem>
                <MenuItem value={10}>karachi</MenuItem>
                <MenuItem value={20}>peshawer</MenuItem>
                <MenuItem value={30}>lahour</MenuItem>
              </Select>
            </FormControl>

            <FormControl
              variant="outlined"
              // className={classes.formControl}
              style={{ width: "47%" }}
            >
              <InputLabel id="demo-simple-select-outlined-label">
                Select-country
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                // value={age}
                // onChange={handleChange}
                label="select-contry"
              >
                <MenuItem value="">{/* <em>None</em> */}</MenuItem>
                <MenuItem value={10}>Paksitan</MenuItem>
                <MenuItem value={20}>India</MenuItem>
                <MenuItem value={30}>Chaina</MenuItem>
              </Select>
            </FormControl>
          </div>
          <div className="inputFeild">
            <TextField
              id="outlined-basic"
              label="Address"
              style={{ width: "97%", height: "20px" }}
              onChange={update}
              name="address"
              value={data.address}
            />
          </div>

          <RadioGroup
            aria-label="gender"
            name="gender1"
            onChange={handleChange}
          >
            <div className="inputFeild">
              <FormControlLabel
                value="female"
                control={<Radio />}
                label="Female"
              />
              <FormControlLabel value="male" control={<Radio />} label="Male" />
              <FormControlLabel
                value="other"
                control={<Radio />}
                label="Other"
              />
            </div>
          </RadioGroup>

          <div className="inputFeild">
            <TextField
              id="outlined-basic"
              label="Password"
              type="password"
              style={{ width: "47%" }}
              onChange={update}
              name="password"
              value={data.password}
            />
            <TextField
              id="outlined-basic"
              label="Confrim password"
              type="password"
              style={{ width: "47%" }}
              onChange={update}
              name="confrim_password"
              value={data.confrim_password}
            />
          </div>
          <p className="para">
            Already have account? <Link to="./login"> login</Link>
          </p>
          <div className="btn">
            <Button
              variant="contained"
              color="primary"
              style={{ width: "97%" }}
              onClick={Submit}
              type="submit"
            >
              Sign Up
            </Button>
          </div>
        </form>
      </div>
    </>
  );
};

export default Signup;
